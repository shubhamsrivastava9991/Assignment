//Validation of an Email ID 

package practice.Project2;

import java.util.ArrayList;
import java.util.Scanner;

public class Emailvalidation {

    public static void main(String[] args) {
        
    	//Creating the arralist
        ArrayList<String> emailID = new ArrayList<String>();
        
        //Adding the element in the arraylist
        emailID.add("shubham@gmail.com");
        emailID.add("ram@yahoo.com");
        emailID.add("mohit@gmail.com");
        emailID.add("max@yahoo.com");
        emailID.add("hena@gmail.com");
        
        //Creating the scanner class object
        Scanner sc = new Scanner(System.in);
        
        //Taking input from the user
        System.out.println("Enter the email: ");
        String email = sc.nextLine();
        
        //Checking the email is null or empty
        if (email == null || email.isEmpty()) {
            System.out.println("You haven't entered an email");
            
       }//Checking the email enter by the user is there in the arraylist or not
        else if(emailID.contains(email)){
             System.out.println("Email ID " + email + " is exist");
        }
        else{
            System.out.println("Email ID " + email + " is not exist");
        }

    }
}



/*
   OUTPUT
-------------------------------------------

Enter the email: 
shubham@gmail.com
Email ID shubham@gmail.com is exist

 
 */
