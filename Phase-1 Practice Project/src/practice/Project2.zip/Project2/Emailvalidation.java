package practice.Project2;

import java.util.*;
import java.util.regex.Pattern;

public class Emailvalidation {

	public static void main(String[] args) {
		
		//Creating object of class scanner
		Scanner sc = new Scanner(System.in);
		
		//Taking input 
		System.out.println("Enter the Email: ");
		String email = sc.nextLine();
		
		//Calling the validateEmail method
		System.out.println("\nEmail " + email + " is : "+ ValidateEmail(email));
		
	}
	
	//Method to tell email is valid or invalid
	public static String ValidateEmail(String email) {
		
		//Checking if email is null or email is empty
		if(email == null || email.isEmpty()) {
			return "Invalid Enter the email";
		}
		
		//Regex Expression
		String emailregex = "^[a-zA-Z0-9_+&*-]+(?:\\."+"[a-zA-Z0-9_+&*-]+)*@" + "(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
		
		//Pattern class that having static method compile and passing regular expression
		Pattern patrn = Pattern.compile(emailregex);
		
		//Checking the email that is valid or not
		if(patrn.matcher(email).matches()) {
			return "Valid Email";
		}else {
			return "Invalid Email";
		}
	}
}


/*
   OUTPUT
-------------------------------------------

Enter the Email: 
abc@gmail.com

Email abc@gmail.com is : Valid Email

 
 */
