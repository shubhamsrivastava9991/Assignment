package practice.Project4;

import java.util.ArrayList;
import java.util.Iterator;

public class Longestincreasingsubsequence {

	public static void main(String[] args) {
	int array[] = { 5, 20, 16, 30, 25, 48, 57, 1, 3, 79, 89, 96, 78 };
		
		//Creating the ArrayList
		ArrayList<Integer> list = new ArrayList<Integer>();
		ArrayList<Integer> longestList = new ArrayList<Integer>();
		
		int currentMax;
		int highestCount = 0;
		
		//using for loop which will add the maximum value into the list 
		for (int i = 0; i < array.length; i++) {
			currentMax = Integer.MIN_VALUE;
			for (int j = i; j < array.length; j++) {
				if (array[j] > currentMax) {
					list.add(array[j]);
					currentMax = array[j];
				}
			}
			
			//Condition to check that highestcount is smaller than the size of the list
			if (highestCount < list.size()) {
				//highestCount will assign with the size of the list
				highestCount = list.size();
				//longlist is assign with the arraylist elemetns which is present in the list
				longestList = new ArrayList<Integer>(list);
			}
			//Remove all the elements from the arraylist
			list.clear();
		}
		//Creating iterator
		Iterator<Integer> itr = longestList.iterator();
		System.out.println("The Longest subsequence are: ");
		//Iterating to the elements present in the arraylist and printing the element
		while (itr.hasNext()) {
			System.out.print(itr.next() + " ");
		}
		
		//Printing the longest subsequence length
		System.out.println("\n\nLength of Longest Increasing Subsequence is: " + highestCount);
	}
}
