//Creating an Arithmetic Calculator

package practice.Project1;

import java.util.Scanner;


public class ArithmeticCalculator {
	
	
	//Method to add two number
	public float add(float num1, float num2) {
		return num1 + num2; 
	}
	
	//Method to subtract two number 
	public float sub(float num1,float num2) {
		
		return num1 - num2;
	}
	
	//Method to multiply two number
	public float mul(float num1, float num2) {
		return num1 * num2;
	}
	
	//Method to divide two number
	public float div(float num1, float num2) {
		return num1 / num2;
	}

	public static void main(String[] args) {
		
		//Creating object of class Calculator
		ArithmeticCalculator c = new ArithmeticCalculator();
		
		//Creating object of class Scanner
		Scanner s = new Scanner(System.in);
		
		//Taking input of first number from user
		System.out.println("Enter the first number: ");
		float num1 = s.nextFloat();
		
		//Taking input of second number from user
		System.out.println("Enter the second number: ");
		float num2= s.nextFloat();
		
		//
		System.out.println("\n+ --> Addition\n- --> Subtraction\n* --> Multiplication\n/ --> Division");
		System.out.println("\nChoose the operation to perform: ");
		
		//Taking character input from user 
		char opr = s.next().charAt(0);
		
		//Performing switch operation
		switch(opr) {
			
		case('+'): 
			 //Calling the add method and then printing the result 
			 System.out.println("\nAddition of " + num1 + " and "+ num2+" is: " + c.add(num1, num2));
			break;
			
		case('-'):
			//Calling the sub method and then printing the result
			System.out.println("\nSubtraction of " + num1 + " and "+ num2 + " is: " + c.sub(num1, num2));
			break;
		
		case('*'):
			//Calling the mul method and then printing the result
			System.out.println("\nMultiplication of " + num1 + " and "+ num2 + " is: " + c.mul(num1, num2));
			break;

		
		case('/'):
			//Applying if condition to check that num2 is zero or not 
			if(num2 == 0){
				System.out.println("Trying to divide by zero which is not possible");
				break;
			}else {
				//Calling the div method and then printing the result
				System.out.println("\nDivision of " + num1 + " and "+ num2 + " is: " + c.div(num1, num2));
				break;
			}
		
		default: 
			System.out.println("Wrong Choice!");
			break;
		}
	}
}
