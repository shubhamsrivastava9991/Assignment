//Creating an Arithmetic Calculator

package practice.Project1;

import java.util.Scanner;

class Calculation{
	
	 private float num1,num2;
	 
	 //Declaring static final to make variable CONSTANT  and initializing with arithmetic operator
	 static final char PLUS ='+'; 
	 static final char MINUS = '-';
	 static final char ASTRIC = '*';
	 static final char BACK_SLASH = '/';
	
	//Parameterize constructor
	Calculation(float num1, float num2){
		this.num1 = num1;
		this.num2 = num2;
	}
	
	    //Method to add two number
		public float add() {
			return this.num1 + this.num2; 
		}
		
		//Method to subtract two number 
		public float sub() {
			
			return this.num1 - this.num2;
		}
		
		//Method to multiply two number
		public float mul() {
			return this.num1 * this.num2;
		}
		
		//Method to divide two number
		public float div() {
			return this.num1 / this.num2;
		}

}


public class ArithmeticCalculator {

	public static void main(String[] args) {
		
		//Creating object of class Scanner
		Scanner s = new Scanner(System.in);
		
		//Taking input of first number from user
		System.out.println("Enter the first number: ");
		float num1 = s.nextFloat();
		
		//Taking input of second number from user
		System.out.println("Enter the second number: ");
		float num2= s.nextFloat();
		
		//Creating object of class Calculator
		Calculation c = new Calculation(num1,num2);
		
        
		System.out.println("\n+ --> Addition\n- --> Subtraction\n* --> Multiplication\n/ --> Division");
		System.out.println("\nChoose the operation to perform: ");
		
		//Taking character input from user 
		char opr = s.next().charAt(0);
		
		//Performing switch operation
		switch(opr) {
		
		//
		case Calculation.PLUS: 
			 //Calling the add method and then printing the result in integer by explicit type casting
			 System.out.println("\nAddition of " + num1 + " and "+ num2+" is: " + (int)c.add());
			break;
			
		case Calculation.MINUS:
			//Calling the sub method and then printing the result in integer by explicit type casting
			System.out.println("\nSubtraction of " + num1 + " and "+ num2 + " is: " + (int)c.sub());
			break;
		
		case Calculation.ASTRIC:
			//Calling the mul method and then printing the result
			System.out.println("\nMultiplication of " + num1 + " and "+ num2 + " is: " + c.mul());
			break;

		
		case Calculation.BACK_SLASH:
			//Applying if condition to check that num2 is zero or not 
			if(num2 == 0){
				System.out.println("Trying to divide by zero which is not possible");
				break;
			}else {
				//Calling the div method and then printing the result
				System.out.println("\nDivision of " + num1 + " and "+ num2 + " is: " + c.div());
				break;
			}
		
		default: 
			System.out.println("Wrong Choice!");
			break;
		}
	}
}
