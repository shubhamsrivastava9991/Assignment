package practice.Project3;

import java.io.FileWriter;
import java.util.Scanner;

public class Writetofile {

	public static void main(String[] args) {
		//creating scanner class object
		Scanner sc = new Scanner(System.in);
		//Taking the input
		System.out.println("Enter the data to write into the file:");
		String data = sc.nextLine();

		try {
			//Creating the filewriter class object
			FileWriter fw = new FileWriter("F:/file.txt");
			//Writing the data to the file
			fw.write(data);
			System.out.println("Data written successfully into the file");
			//Closing the file
			fw.close();
			
		}catch (Exception e) {
			e.getMessage();
		}
	}
}
