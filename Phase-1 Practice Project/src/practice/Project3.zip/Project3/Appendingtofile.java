package practice.Project3;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Appendingtofile {

	public static void main(String[] args) throws IOException {
		//Creating the datainputstream object
		DataInputStream di = new DataInputStream(System.in);
		//Creating the fileoutputstream object
		FileOutputStream fout = new FileOutputStream("F:/file.txt",true);
		//Creating the bufferedoutputstream object
		BufferedOutputStream bout = new BufferedOutputStream(fout,100000);
		
		System.out.println("Enter the data to append and at the end type '@' to end:");
		char ch;
		//Writing the data into file until the user not type the '@' at the end
		while((ch=(char)di.read())!='@'){
			//write to the file
			bout.write(ch);
			
		}
		System.out.println("Data Successfully appended to the file");
		//Closing the file
		bout.close();
	}
}
