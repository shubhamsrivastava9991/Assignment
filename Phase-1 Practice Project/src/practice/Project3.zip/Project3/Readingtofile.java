package practice.Project3;

import java.io.FileInputStream;
import java.io.IOException;

public class Readingtofile {

	public static void main(String[] args) throws IOException {
	//Creating the fileinputstream object
	FileInputStream fin = new FileInputStream("F:/file.txt");
		
		System.out.println("FileContents are: ");
		
		int ch;
		
		//Condition to read the file and display the data
		while((ch=fin.read())!=-1){
			System.out.print((char)ch);
			
		}
		//Closing the file
		fin.close();
	}
}
