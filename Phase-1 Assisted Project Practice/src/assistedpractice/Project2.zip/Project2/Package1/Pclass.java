package assistedpractice.Project2.Package1;

public class Pclass {
	
	public void methodPpublic(){
		System.out.println("Class P Public Method");
		
	}
	
	private void methodPprivate(){
		System.out.println("Class P Private Method");
	}
	
	void methodPdefault(){
		System.out.println("Class P Default Method");
	}
	
	protected void methodPprotected(){
		System.out.println("Class P Protected Method");
	}

	public static void main(String[] args) {
		System.out.println("This is P Class");
		Mclass ob1 = new Mclass();
		System.out.println("Value of class M long is: " + ob1.b);
		System.out.println("Value of class M float is: " + ob1.c);
		
		Nclass ob2 = new Nclass();
		System.out.println("Value of class N int is: " + ob2.d);
		System.out.println("Value of class N long is: " + ob2.e);
		System.out.println("Value of class N double is: " + ob2.f);
		
	}
}

/*
    Output

This is P Class
Value of class M long is: 535
Value of class M float is: 20.78
Value of class N int is: 30
Value of class N long is: 750
Value of class N double is: 150.5

 */
