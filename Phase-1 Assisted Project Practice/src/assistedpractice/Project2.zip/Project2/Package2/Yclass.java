package assistedpractice.Project2.Package2;

import assistedpractice.Project2.Package1.*;

public class Yclass extends Nclass{

	public static void main(String[] args) {
			
			System.out.println("This is Class Y");
			
			new Mclass().methodpublic();
			new Yclass().methodNprotected();
			new Nclass().methodNpublic();
			
			Xclass ob = new Xclass();
			System.out.println("CLass X value of long is: " + ob.g);
			System.out.println("CLass X value of float is: " + ob.h);
			System.out.println("CLass X value of char is: " + ob.i);
			
		}
	}

/*
 	Output
 	
This is Class Y
Class M Public Method
Class N Protected Method
Class N Public Method
CLass X value of long is: 9501
CLass X value of float is: 35.6
CLass X value of char is: y

 	
 */