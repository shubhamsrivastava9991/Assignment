package assistedpractice.Project2.Package2;

public class Xclass {

	private int f = 300;
	long g = 9501L;
	protected float h = 35.6f;
	public char i = 'y';
	
}
