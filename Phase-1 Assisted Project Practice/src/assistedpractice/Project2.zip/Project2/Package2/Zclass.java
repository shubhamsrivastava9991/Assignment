package assistedpractice.Project2.Package2;

import assistedpractice.Project2.Package1.*;

public class Zclass extends Mclass{

	public static void main(String[] args) {
		
		System.out.println("This is Class Z");
		
		new Mclass().methodpublic();
		new Zclass().methodprotected();
		new Nclass().methodNpublic();
		new Pclass().methodPpublic();
		
		Xclass ob = new Xclass();
		System.out.println("CLass X value of long is: " + ob.g);
		System.out.println("CLass X value of float is: " + ob.h);
		System.out.println("CLass X value of char is: " + ob.i);
	}

}

/*
  Output
 
This is Class Z
Class M Public Method
Class M Protected Method
Class N Public Method
Class P Public Method
CLass X value of long is: 9501
CLass X value of float is: 35.6
CLass X value of char is: y

 */