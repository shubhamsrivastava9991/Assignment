//Writing a program in Java to implement implicit and explicit type casting

package assistedpractice.Project1;

public class ImpliciteandExplicit {

	public static void main(String[] args) {
		
		System.out.println("Implicit Typecasting:");
		
		char c = 'J';
		
		//Implicit conversion of char --> int 
		int a = c;
		System.out.println("The conversion of char datatype c: " + c + " " + " to int datatype a is: " + a);
		
		//Implicit conversion of int --> long 
		long l = a;

		System.out.println("The conversion of int datatype a: " + a + " " + " to long datatype l is: " + l);
		
		//Implicit conversion of long --> float 
		float f = l;
		System.out.println("The conversion of long datatype l: " + l + " " + " to float datatype f is: " + f);
		
		System.out.println("*************************************************************************************");
		System.out.println("Explicit Typecasting:");
		
	    float d = 68.854623f;
	    	
		long h = (long) d;
		System.out.println("The conversion of float datatype d: " + d + " " + " to long datatype h is: " + h);
		
		char j = (char) h;
		System.out.println("The conversion of long datatype h: " + h + " " + " to char datatype j is: " + j);
		
		byte b = (byte) j;
		System.out.println("The conversion of char datatype j: " + j + " " + " to byte datatype b is: " + b);
	}

}
