//Writing a program in Java to implement implicit and explicit type casting

package assistedpractice.Project1;

public class ImpliciteandExplicit {

	public static void main(String[] args) {
		
		System.out.println("Implicit Typecasting:");
		
		char c = 'J';
		
		//Implicit conversion of char --> int 
		int a = c;
		System.out.println("The conversion of char datatype c: " + c + " " + " to int datatype a is: " + a);
		
		//Implicit conversion of int --> long 
		long l = a;

		System.out.println("The conversion of int datatype a: " + a + " " + " to long datatype l is: " + l);
		
		//Implicit conversion of long --> float 
		float f = l;
		System.out.println("The conversion of long datatype l: " + l + " " + " to float datatype f is: " + f);
		
		System.out.println("*************************************************************************************");
		System.out.println("Explicit Typecasting:");
		
	    float d = 68.854623f;
	    	
		long h = (long) d;
		System.out.println("The conversion of float datatype d: " + d + " " + " to long datatype h is: " + h);
		
		char j = (char) h;
		System.out.println("The conversion of long datatype h: " + h + " " + " to char datatype j is: " + j);
		
		byte b = (byte) j;
		System.out.println("The conversion of char datatype j: " + j + " " + " to byte datatype b is: " + b);
	}

}

/*
 		Output
 		
Implicit Typecasting:
The conversion of char datatype c: J  to int datatype a is: 74
The conversion of int datatype a: 74  to long datatype l is: 74
The conversion of long datatype l: 74  to float datatype f is: 74.0
*************************************************************************************
Explicit Typecasting:
The conversion of float datatype d: 68.85462  to long datatype h is: 68
The conversion of long datatype h: 68  to char datatype j is: D
The conversion of char datatype j: D  to byte datatype b is: 68
*/
