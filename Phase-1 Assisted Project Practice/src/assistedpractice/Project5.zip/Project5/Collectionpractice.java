//Writing a program in Java to verify implementations of collections

package assistedpractice.Project5;

import java.util.*;

public class Collectionpractice {

	public static void main(String[] args) {
		
		//Creating ArrayList
		System.out.println("ArrayList");
		ArrayList<String> arr = new ArrayList<String>();
		
		//Adding Element in ArrayList
		arr.add("JAVA");
		arr.add("Python");
		arr.add("C#");
		arr.add("C++");
		
		//Printing the Elements in ArrayList
		System.out.println("Elements in arraylist are: "+ arr);
		
		//Printing the Elements index in ArrayList
		System.out.println("Elements at index 3 is: " + arr.get(3));
		
		
		//Creating Vector 
		System.out.println("\nVector");
		Vector<String> vect = new Vector<String>();
		
		//Adding Element in Vector
		vect.add("Red");
		vect.add("Blue");
		vect.add("Green");
		vect.add("Yellow");
		
		//Printing the Elements in the Vector
		System.out.println("Elements in Vector are: "+ vect);
		
		//Printing the Elements index in the vector
		System.out.println("Elements at index 2: "+ vect.get(2));
		
		//Creating LinkList
		System.out.println("\nLinklist");
		LinkedList<Integer> linkl = new LinkedList<Integer>();
		
		//Adding Elements in the LinkList
		linkl.add(254);
		linkl.add(578);
		linkl.add(120);
		linkl.add(478);
		linkl.add(612);
		
		//Printing the Elements in the LinkList
		System.out.println("Elements in Linklist are: "+ linkl);
		
		//Printing the Elements Index in the LinkList
		System.out.println("Elements at index at 4 is: "+ linkl.get(4));
		
		//Creating HashSet
		System.out.println("\nHashset");
		HashSet<Integer> hset = new HashSet<Integer>();
		
		//Adding elements in the HashSet
		hset.add(12);
		hset.add(13);
		hset.add(15);
		hset.add(20);
		hset.add(25);
		
		//Printing the Elements in the HashSet
		System.out.println("Elements in Hashset are: " + hset);
		//Printing the Elements Size of the HashSet
		System.out.println("Elemets in the Hashset is: "+ hset.size());

		
		//Creating the LinkedHashet
		System.out.println("\nLinkedHashSet");
		LinkedHashSet<Integer> lhset = new LinkedHashSet<Integer>();
		
		//Adding Elements in the LinkedHashSet 
		lhset.add(48);
		lhset.add(87);
		lhset.add(58);
		lhset.add(25);
		
		//Printing the Elements in the LinkedHashSet 
		System.out.println("Elements in LinkedHashSet are: "+ lhset);
		//Printing the Elements size of the LinkedHashSet
		System.out.println("ELemets in the LinkedHashSet is: "+ lhset.size() );
		
	}

}


/*
        OUTPUT
*********************************************************
ArrayList
Elements in arraylist are: [JAVA, Python, C#, C++]
Elements at index 3 is: C++

Vector
Elements in Vector are: [Red, Blue, Green, Yellow]
Elements at index 2: Green

Linklist
Elements in Linklist are: [254, 578, 120, 478, 612]
Elements at index at 4 is: 612

Hashset
Elements in Hashset are: [20, 25, 12, 13, 15]
Elemets in the Hashset is: 5

LinkedHashSet
Elements in LinkedHashSet are: [48, 87, 58, 25]
ELemets in the LinkedHashSet is: 4

*/
